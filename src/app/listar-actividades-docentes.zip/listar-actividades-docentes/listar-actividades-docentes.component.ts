import { Component } from '@angular/core';

@Component({
  selector: 'app-listar-actividades-docentes',
  templateUrl: './listar-actividades-docentes.component.html',
  styleUrls: ['./listar-actividades-docentes.component.css']
})
export class ListarActividadesDocentesComponent {

}
