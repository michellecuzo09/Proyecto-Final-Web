import { Component } from '@angular/core';

@Component({
  selector: 'app-listar-extra-actividades',
  templateUrl: './listar-extra-actividades.component.html',
  styleUrls: ['./listar-extra-actividades.component.css']
})
export class ListarExtraActividadesComponent {

}
